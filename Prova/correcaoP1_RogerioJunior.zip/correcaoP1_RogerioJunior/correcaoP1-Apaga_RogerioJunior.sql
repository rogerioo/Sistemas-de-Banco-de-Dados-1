﻿-- ---------------------     << Prova 01 >>     ---------------------
--
--                    SCRIPT DE APAGA (DDL)
--
-- Data Criacao ...........: 17/10/2019
-- Autor(es) ..............: Rogério S. dos Santos Júnior
-- Banco de Dados .........: MySQL
-- Banco de Dados(nome) ...: RogerioJunior
-- 
-- PROJETO => 07 Base de Dados
--         => 11 Tabelas
--
-- -----------------------------------------------------------------

USE RogerioJunior;

DROP TABLE relaciona;
DROP TABLE tem;
DROP TABLE possui;
DROP TABLE email;
DROP TABLE INTERESSE;
DROP TABLE CARACTERISTICA;
DROP TABLE PESSOA;