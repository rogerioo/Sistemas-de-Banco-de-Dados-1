-- --------------------- P1 - A 2019/1 ------------------------
-- Linguagem: Mysql
-- 
-- 01 Base de Dados
-- 06 Tabelas
-- 
-- ------------------------------------------------------------

USE p1A;

DROP TABLE ADMITIDO;
DROP TABLE telefone;
DROP TABLE UNIVERSIDADE;
DROP TABLE DOCENTE;
DROP TABLE CURSO;
DROP TABLE ALUNO;