-- --------------------     << Detran >>     -----------------------
--
--                    SCRIPT APAGA (DML)
--
-- Data Criacao ...........: 30/09/2019
-- Autor(es) ..............: Rogério S. dos Santos Júnior
-- Banco de Dados .........: MySQL
-- Banco de Dados(nome) ...: aula4exer6Evolucao4
--
-- Data Ultima Alteracao ..: 14/10/2019
--   => Criação do script de apagar
--
-- PROJETO => 01 Base de Dados
--         => 09 Tabelas
-- -----------------------------------------------------------------

use aula4exer6Evolucao4;

DROP TABLE INFRACAO;
DROP TABLE VEICULO;
DROP TABLE telefone;
DROP TABLE PROPRIETARIO;
DROP TABLE CATEGORIA;
DROP TABLE AGENTE;
DROP TABLE MODELO;
DROP TABLE LOCAL;
DROP TABLE TIPO_INFRACAO;