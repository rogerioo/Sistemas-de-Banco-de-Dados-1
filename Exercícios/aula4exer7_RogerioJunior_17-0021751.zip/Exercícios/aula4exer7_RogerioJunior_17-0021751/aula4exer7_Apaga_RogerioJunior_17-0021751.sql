-- ---------------------   << Empresa FUI  >>   ---------------------
--
--                    SCRIPT DE APAGAR (DDL)
-- 
-- Data Criacao ...........: 04/11/2019
-- Autor(es) ..............: Rogério S. dos Santos Júnior
-- Banco de Dados .........: MySQL
-- Banco de Dados(nome) ...: aula4exer7
-- 
-- 
-- PROJETO => 01 Base de Dados
--         => 10 Tabelas
-- 
-- -----------------------------------------------------------------

USE aula4exer7;

DROP TABLE trabalha;
DROP TABLE tem;
DROP TABLE gerencia;
DROP TABLE ligacao;
DROP TABLE EMPREGADO;
DROP TABLE PROJETO;
DROP TABLE DEPARTAMENTO;
DROP TABLE LOCALIZACAO;
DROP TABLE DEPENDENTE;
DROP TABLE PESSOA;